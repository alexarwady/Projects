<!DOCTYPE html>
<html>

<head>
    <title>Edit Attendance</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            color: #3B056F;
            font-family: 'Open Sans', sans-serif;
            font-size: 25px;
            text-align: center;
        }
        th {
            background-color: #3B056F;
            color: white;
        }
        tr:nth-child(even) {background-color: #f2f2f2}
        a{text-decoration: none;}
    </style>
</head>

<header>
    <div class="container">
        <img src="Picture4.png" width="280" height="90" style="padding: 10px 10px 5px 100px;">

        <nav>
            <ul>
                <li><a href="index_admin.php">Home</a></li>
                <li><a href="attendance_summary.php">Summary</a></li>
                <li><a href="companion_summary.php">Companions</a></li>
            </ul>
        </nav>
    </div>
</header>

<body>

<br style="line-height: 10px" />

<table>
    <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Total Hours</th>
    </tr>
    <?php
    session_start();
    $db = mysqli_connect('localhost', 'root', '', 'registration');
    $query = "SELECT a.firstname, a.lastname, b.total FROM users AS a, totalhours AS b WHERE a.username=b.username AND a.username<>"."'".$_SESSION['username']."' ORDER BY firstname, lastname";
    $result = $db->query($query);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["firstname"]. "</td><td>" . $row["lastname"] . "</td><td>". $row["total"] . "</td><td>";
        }
        echo "</table>";
    }
    $db->close();
    ?>
</table>
<br>
</body>
</html>