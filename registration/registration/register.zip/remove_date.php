<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "registration");
// Check connection
$sql = "DELETE FROM `attendance` WHERE `date1` = '$_GET[date1]' AND username="."'".$_SESSION['username']."'";
$result = $conn->query($sql);
if($result)
    header("refresh:0; url=edithours.php");
else
    echo "Not deleted"
?>